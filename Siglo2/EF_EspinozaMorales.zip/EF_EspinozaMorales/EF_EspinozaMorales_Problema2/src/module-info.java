/**
 * 
 */
/**
 * 
 */
module EF_EspinozaMorales_Problema2 {
	requires java.desktop;
}
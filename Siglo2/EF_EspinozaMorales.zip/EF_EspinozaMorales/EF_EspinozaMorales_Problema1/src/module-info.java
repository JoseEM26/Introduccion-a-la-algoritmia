/**
 * 
 */
/**
 * 
 */
module EF_EspinozaMorales_Problema1 {
	requires java.desktop;
}